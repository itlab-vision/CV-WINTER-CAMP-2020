#include <random>

#include "main_header.h"

void generationHamilton(dcomplex * iH, unsigned int size)
{
	random_device rd;
	mt19937 gen(rd());
	uniform_real_distribution<double> uniform_distance(1, 10.001);
	for (unsigned int i = 0; i < size; i++)
	{
		iH[i*size + i] = dcomplex(0.0, -uniform_distance(gen));
		for (unsigned int j = i + 1; j < size; j++)
		{
			double re = -uniform_distance(gen);
			double im = -uniform_distance(gen);
			iH[i*size + j] = dcomplex(re, im);
			iH[j*size + i] = dcomplex(-re, im);
		}
	}
}

void generationY0(dcomplex * y, unsigned int size)
{
	memset(y, 0, size * size * sizeof(dcomplex));
	for (unsigned int i = 0; i < size; i++)
	{
		y[i*size + i] = dcomplex(1.0, 0.0);
	}
}