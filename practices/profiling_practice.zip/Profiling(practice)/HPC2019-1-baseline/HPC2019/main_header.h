#pragma once
#include <complex>

using namespace std;
typedef complex<double> dcomplex;

void generationHamilton(dcomplex * iH, unsigned int size);
void generationY0(dcomplex * y, unsigned int size);
void RK4(dcomplex * iH, dcomplex * y0, double h, unsigned int steps, unsigned int size);
void matrix_mult(dcomplex * a, dcomplex * b, dcomplex * res, unsigned int size);