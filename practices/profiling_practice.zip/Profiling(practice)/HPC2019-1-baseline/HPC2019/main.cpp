﻿#include <iostream>
#include <chrono>

#include "main_header.h"


int main()
{
	dcomplex *iH, *y;
	unsigned int size = 1000;
	unsigned int steps = 1;
	double h = 0.001 / (double)steps;
	chrono::time_point<chrono::system_clock> start, end;
	start = chrono::system_clock::now();

	iH = new dcomplex[size * size];
	y = new dcomplex[size * size];
	generationHamilton(iH, size);
	generationY0(y, size);

	RK4(iH, y, h, steps, size);
	end = chrono::system_clock::now();

	int elapsed_seconds = chrono::duration_cast<chrono::milliseconds>
		(end - start).count();
	cout << "Total time: " << elapsed_seconds/1000.0 << " sec" << endl;

	//system("pause");
	
	return 0;
}
