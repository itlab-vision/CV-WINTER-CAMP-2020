//#include <windows.h>
#include <stdio.h>
#include <string.h>
//#pragma pack( show )
#pragma pack(push, 1)
#if 1
typedef unsigned char BYTE;
typedef int   DWORD;
typedef short WORD;
typedef int   LONG;
typedef struct tagBITMAPINFOHEADER {
	DWORD      biSize;
	LONG       biWidth;
	LONG       biHeight;
	WORD       biPlanes;
	WORD       biBitCount;
	DWORD      biCompression;
	DWORD      biSizeImage;
	LONG       biXPelsPerMeter;
	LONG       biYPelsPerMeter;
	DWORD      biClrUsed;
	DWORD      biClrImportant;
} BITMAPINFOHEADER, /*FAR *LPBITMAPINFOHEADER,*/ *PBITMAPINFOHEADER;

typedef struct tagBITMAPFILEHEADER {
	WORD    bfType;
	DWORD   bfSize;
	WORD    bfReserved1;
	WORD    bfReserved2;
	DWORD   bfOffBits;
} BITMAPFILEHEADER, /*FAR *LPBITMAPFILEHEADER,*/ *PBITMAPFILEHEADER;

typedef struct tagBITMAPCOREHEADER {
	DWORD   bcSize;                 /* used to get to color table */
	WORD    bcWidth;
	WORD    bcHeight;
	WORD    bcPlanes;
	WORD    bcBitCount;
} BITMAPCOREHEADER, /*FAR *LPBITMAPCOREHEADER,*/ *PBITMAPCOREHEADER;

#define BI_RGB        0L
#define BI_RLE8       1L
#define BI_RLE4       2L
#define BI_BITFIELDS  3L
#define BI_JPEG       4L
#define BI_PNG        5L
typedef struct tagRGBQUAD {
	BYTE    rgbBlue;
	BYTE    rgbGreen;
	BYTE    rgbRed;
	BYTE    rgbReserved;
} RGBQUAD;

#endif
typedef struct Image_tag{
    int                 step;
    int                 nchan;
    unsigned char*      data;
    PBITMAPINFOHEADER   infohdr;
    BITMAPFILEHEADER    filehdr;
    int                 infohdr_size;
} tImage;
extern int readBMP(FILE* f, tImage* img );
extern int saveBMP(FILE* f, tImage* img);
extern int loadBMP(char* in_name, unsigned char* data);
extern int storeBMP(char* out_name, unsigned char* data);

extern getBMPSize(char* in_name, int* width, int* height);

//#pragma pack(pop)