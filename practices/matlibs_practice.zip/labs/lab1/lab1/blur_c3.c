typedef unsigned char uchar;

/*1. Initial implementation of filter blur*/
void blur_c3(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w)
{
    int j, i, y, x;
    float div = kw * kh;
    for (i = 0; i < h; i++) {
        for (j = 0; j < w; j++) {
            uchar* s = src + 3 * j;
            uchar* d = dst + 3 * j;
            float sum0 = 0;
            float sum1 = 0;
            float sum2 = 0;
            for (y = 0; y < kh; y++) {
                for (x = 0; x < kw; x++) {
                    sum0 = sum0 + s[st*y + 3 * x + 0];
                    sum1 = sum1 + s[st*y + 3 * x + 1];
                    sum2 = sum2 + s[st*y + 3 * x + 2];
                }
            }
            d[0] = (uchar)(sum0 / div);
            d[1] = (uchar)(sum1 / div);
            d[2] = (uchar)(sum2 / div);

        }
        src = src + st;
        dst = dst + st;
    }
}
