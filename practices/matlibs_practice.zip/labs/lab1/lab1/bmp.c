//#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "bmp.h"
//#pragma pack( show )
extern int readBMP( FILE* f, tImage* img )
{
    int m, n, l, colorbytes, totalbytes;
    BITMAPINFOHEADER  infohdr;
    BITMAPFILEHEADER  filehdr;
    BITMAPCOREHEADER  core;
    char* quads;

    if( NULL == f ) return 1;
    l = sizeof(BITMAPFILEHEADER);
    n = (int)fread( &filehdr, 1, l, f );
    memcpy(&img->filehdr, &filehdr, sizeof(BITMAPFILEHEADER));
    if( n != l ){
        printf("\nError: Can't read bmp-file header...\n");
        fclose( f );
        return 1;
    }
    if( 0x4d42 != filehdr.bfType ){
        printf("\nError: Wrong type of source file...\n"); 
        fclose( f );
        return 1;
    }
    fread( &m, 1, 4, f );
    if( m == sizeof(BITMAPINFOHEADER)){
        l = sizeof(BITMAPINFOHEADER) - 4;
        n = (int)fread( &infohdr.biWidth, 1, l, f );
        if( n != l ){
            printf("\nError: Can't read bmp-header from source file...\n");
            fclose( f );
            return 1;
        }
    } else {
        l = sizeof(BITMAPCOREHEADER) - 4;
        n = (int)fread( &core.bcWidth, 1, l, f );
        if( n != l ){
            printf("\nError: Can't read bmp-header from source file...\n");
            fclose( f );
            return 1;
        }
		memset(&infohdr, 0, sizeof(BITMAPINFOHEADER));
        infohdr.biWidth    = core.bcWidth;
        infohdr.biHeight   = core.bcHeight;
        infohdr.biPlanes   = core.bcPlanes;
        infohdr.biBitCount = core.bcBitCount;
    }
    infohdr.biSize = sizeof(BITMAPINFOHEADER);
    if( 0 == infohdr.biSizeImage )
        infohdr.biSizeImage =
        (((( infohdr.biWidth * infohdr.biBitCount ) + 31) & ~31) >> 3) * 
        infohdr.biHeight;
    if( 0 == infohdr.biClrUsed ){
        if( BI_BITFIELDS == infohdr.biCompression )
            infohdr.biClrUsed = 3;
        else 
            infohdr.biClrUsed = infohdr.biBitCount < 16 ? 1 << 
            infohdr.biBitCount : 0;
    }
    img->step   = ((( infohdr.biWidth * infohdr.biBitCount ) + 31) & ~31) >> 3;
    switch( infohdr.biBitCount ){
        case 8:
            img->nchan = 1;
            break;
        case 16:
        case 24:
            img->nchan = 3;
            break;
        case 32:
            img->nchan = 4;
            break;
    }
    colorbytes   = sizeof(RGBQUAD) * infohdr.biClrUsed;
    totalbytes   = sizeof(BITMAPINFOHEADER) + colorbytes;
    img->infohdr = (BITMAPINFOHEADER*)malloc( totalbytes );
    img->infohdr_size = totalbytes;
    img->data    = (unsigned char*)malloc( infohdr.biSizeImage );
    quads = (char*)img->infohdr + sizeof(BITMAPINFOHEADER);
    memcpy( img->infohdr, &infohdr, sizeof(infohdr) );
    n = (int)fread( quads, 1, colorbytes, f );
    if( n != colorbytes ){
        printf("\nError while reading bmp-file color table...\n");
        fclose( f );
        return 1;
    }
    n = (int)fread( img->data, (size_t)1,(size_t) infohdr.biSizeImage, f );
    if( n != (int)infohdr.biSizeImage ){
        printf("\nError while reading bmp-file data...\n");
        fclose( f );
        return 1;
    }
    fclose( f );
    return 0;
}

extern int saveBMP(FILE* f, tImage* img)
{
    int n;
    n = (int)fwrite(&img->filehdr, 1, sizeof(BITMAPFILEHEADER), f);
    n = (int)fwrite(img->infohdr, 1, sizeof(BITMAPINFOHEADER), f);
    n = (int)fwrite(img->data, (size_t)1, (size_t)img->infohdr->biSizeImage, f);
    return 0;
}

tImage __img;
extern int loadBMP(char* in_name, unsigned char* data)
{
    FILE *  f;
    f = fopen(in_name, "rb");
    if (f == NULL) {
        printf("Cannot open %s\n", in_name);
        return (-1);
    }
    readBMP(f, &__img);
    fclose(f);
    int height = __img.infohdr->biHeight;
    int width  = __img.infohdr->biWidth;
    unsigned char* p = (unsigned char*)__img.data + __img.step * (height - 1);
    int i, j, n, c;
    /*Lines in bmp file are in inverse order.*/
    for (i = 0; i < height; i++) {
        for (j = 0; j < 3 * width; j++) {
            data[3 * width*i + j] = p[j];
        }
        p = p - __img.step;
    }

}
extern int storeBMP(char* out_name, unsigned char* data)
{
    FILE *  f;
    unsigned char* p;
    int i, j;
    int height = __img.infohdr->biHeight;
    int  width = __img.infohdr->biWidth;

    int st = 3 * __img.infohdr->biWidth;
    p = (unsigned char*)__img.data + st * (__img.infohdr->biHeight - 1);
    for (i = 0; i < height; i++) {
        for (j = 0; j < width * 3; j++) {
            p[j] = data[3 * width*i + j];
        }
        p = p - st;
    }
    f = fopen(out_name, "wb");
    if (f == NULL) {
        printf("Cannot open %s\n", out_name);
        return (-1);
    }
    saveBMP(f, &__img);
    fclose(f);

}

extern getBMPSize(char* in_name, int* width, int* height)
{
    tImage img;
    FILE *  f;
    f = fopen(in_name, "rb");
    if (f == NULL) {
        printf("Cannot open %s\n", in_name);
        return (-1);
    }
    readBMP(f, &img);
    fclose(f);
    *height = img.infohdr->biHeight;
    *width = img.infohdr->biWidth;

}