typedef unsigned char uchar;
/*3. Using of separability filter blur*/
/*3.1 Apply horizontal filter*/
static void row_c3(uchar* src, int kw, int w, float* buf)
{
    int j;
    for (j = 0; j < w; j++) {
        uchar* s = src + 3 * j;
        int x;
        float sum0 = 0;
        float sum1 = 0;
        float sum2 = 0;

        for (x = 0; x < kw; x++) {
            sum0 = sum0 + s[3 * x + 0];
            sum1 = sum1 + s[3 * x + 1];
            sum2 = sum2 + s[3 * x + 2];
        }
        buf[3 * j + 0] = sum0;
        buf[3 * j + 1] = sum1;
        buf[3 * j + 2] = sum2;

    }
}
/*3.2 Apply vertical filter */
void blur_c3_sep(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w, float* buf[])
{
    int j, i, y, x, k;
    float div = kw * kh;
    uchar* src0 = src;
    uchar* dst0 = dst;
    float* b[5];
    for (k = 0; k < 5; k++) {
        b[k] = buf[k];
    }
    src = src0;
    dst = dst0;

    for (y = 0; y < kh - 1; y++) {
        row_c3(src, kw, w, b[y]);
        src = src + st;
    }
    int curr_b = 4;
    for (i = 0; i < h; i++) {
        row_c3(src, kw, w, b[curr_b]);
        for (j = 0; j < w; j++) {
            uchar* d = dst + 3 * j;
            float sum0 = 0;
            float sum1 = 0;
            float sum2 = 0;
            for (y = 0; y < kh; y++) {
                sum0 = sum0 + b[y][3 * j + 0];
                sum1 = sum1 + b[y][3 * j + 1];
                sum2 = sum2 + b[y][3 * j + 2];
            }
            d[0] = (uchar)(sum0 / div);
            d[1] = (uchar)(sum1 / div);
            d[2] = (uchar)(sum2 / div);
        }
        src = src + st;
        dst = dst + st;
        if (curr_b == 4) curr_b = 0;
        else curr_b++;
    }
}
