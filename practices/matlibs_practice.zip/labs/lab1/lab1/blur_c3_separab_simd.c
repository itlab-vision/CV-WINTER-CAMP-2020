#include "intrin.h"
typedef unsigned char uchar;

void row_c3_simd(uchar* src, int kw, int w, float* buf)
{
#if 0
    int j;
    for (j = 0; j < w; j++) {
        uchar* s = src + 3 * j;
        int x;
        __m128i x0, x1;
        __m128  f0;
        __m128  sum;
        sum = _mm_setzero_ps();
        for (x = 0; x < kw; x++) {
            x0 = _mm_loadu_si128(s + 3 * x);
            x1 = _mm_cvtepu8_epi32(x0);
            f0 = _mm_cvtepi32_ps(x1);
            sum = _mm_add_ps(sum, f0);
        }
        _mm_storeu_ps(buf + 3 * j, sum);
    }
#else
    int j;
    for (j = 0; j < w; j++) {
        uchar* s = src + 3 * j;
        int x;
        float sum0 = 0;
        float sum1 = 0;
        float sum2 = 0;

        for (x = 0; x < kw; x++) {
            sum0 = sum0 + s[3 * x + 0];
            sum1 = sum1 + s[3 * x + 1];
            sum2 = sum2 + s[3 * x + 2];
        }
        buf[3 * j + 0] = sum0;
        buf[3 * j + 1] = sum1;
        buf[3 * j + 2] = sum2;

    }

#endif
}
void blur_c3_sep_simd(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w, float* buf[])
{
    int j, i, y, x, k;
    float div = kw * kh;
    uchar* src0 = src;
    uchar* dst0 = dst;
    float* b[5];
    for (k = 0; k < kh; k++) {
        b[k] = buf[k];
    }
    src = src0;
    dst = dst0;
    __m128 idiv0 = _mm_set1_ps(1.0 / (kw*kh));
    for (y = 0; y < kh - 1; y++) {
        row_c3_simd(src, kw, w, b[y]);
        src = src + st;
    }
    int curr_b = kh - 1;
    for (i = 0; i < h; i++) {
        row_c3_simd(src, kw, w, b[curr_b]);
        for (j = 0; j < w; j++) {
            uchar* d = dst + 3 * j;
            __m128i x0, x1;
            __m128  f0;
            __m128  sum;
            sum = _mm_setzero_ps();

            for (y = 0; y < kh; y++) {
                f0 = _mm_loadu_ps(b[y] + 3 * j + 0);
                sum = _mm_add_ps(sum, f0);
            }
            f0 = _mm_mul_ps(sum, idiv0);
            x0 = _mm_cvtps_epi32(f0);
            d[0] = _mm_extract_epi8(x0, 0);
            d[1] = _mm_extract_epi8(x0, 4);
            d[2] = _mm_extract_epi8(x0, 8);
        }
        src = src + st;
        dst = dst + st;
        if (curr_b == 4) curr_b = 0;
        else curr_b++;
    }
}
