#include "intrin.h"

typedef unsigned char uchar;

/*2. Vectorized implementation */
void blur_c3_simd(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w)
{
    int j, i, y, x;
    float div = kw * kh;

    __m128 div0 = _mm_set1_ps(kw*kh);
    __m128 idiv0 = _mm_set1_ps(1.0 / (kw*kh));
    for (i = 0; i < h; i++) {
        for (j = 0; j < w; j++) {
            uchar* s = src + 3 * j;
            uchar* d = dst + 3 * j;
            __m128i x0, x1;
            __m128  f0;
            __m128  sum;
            sum = _mm_setzero_ps();

            for (y = 0; y < kh; y++) {
                for (x = 0; x < kw; x++) {
                    x0 = _mm_loadu_si128(s + st * y + 3 * x + 0);
                    x1 = _mm_cvtepu8_epi32(x0);
                    f0 = _mm_cvtepi32_ps(x1);
                    sum = _mm_add_ps(sum, f0);
                }
            }
            f0 = _mm_mul_ps(sum, idiv0);
            x0 = _mm_cvtps_epi32(f0);
            d[0] = _mm_extract_epi8(x0, 0);
            d[1] = _mm_extract_epi8(x0, 4);
            d[2] = _mm_extract_epi8(x0, 8);

        }
        src = src + st;
        dst = dst + st;
    }
}
