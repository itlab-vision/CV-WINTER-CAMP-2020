#include <stdio.h>
#include <malloc.h>
#include <intrin.h>
#include <omp.h>
#include "bmp.h"

typedef unsigned char uchar;
extern void blur_c3(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w);/*1. Initial implementation of filter blur*/
extern void blur_c3_simd(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w);/*2. Vectorized implementation */
extern void blur_c3_sep(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w, float* buf[]);/*3. Using of separability filter blur*/
extern void blur_c3_sep_simd(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w, float* buf[]);
extern void blur_c3_ipp(uchar* src, uchar* dst, int st, int kh, int kw, int h, int w);

/*Compare two images on simailarity*/
void test(uchar* ref, uchar* dst, int st, int h, int w)
{
    int i, j, c;
    for (i = 0; i < h; i++) {
        for (j = 0; j < 3*w; j+=3) {
            for (c = 0; c < 3; c++) {
                int diff = ref[3*j + c] - dst[3*j + c];
                if (diff < 0) diff = -diff;
                if (diff>1) {
                    printf("fail, j=%d, i=%d, c=%d\n", j, i, c);
                    printf("ref=%d\n", ref[3*j + c]);
                    printf("dst=%d\n", dst[3*j + c]);
                    return (-1);
                }
            }
        }
        dst = dst + st;
        ref = ref + st;
    }
    return 0;
}

int main()
{
    int i, j, n, c, kh, kw, h, w;
    int width, height;
    int res = 0;
    res = getBMPSize("input.bmp", &width, &height);
    if (res == -1) return (-1);

    uchar*  src  = malloc(height * 3 * width);
    uchar*  dst1 = malloc(height * 3 * width); //for initial version
    uchar*  dst2 = malloc(height * 3 * width); //for initial version and intrinsics
    uchar*  dst3 = malloc(height * 3 * width); //for separable
    uchar*  dst4 = malloc(height * 3 * width); //for separable + intrinsics
    uchar*  dst5 = malloc(height * 3 * width); //for ipp
    uchar* p;
    int st = width * 3;

    loadBMP("input.bmp", src);

    /*Blur kernel height and width*/
    kh = 5;
    kw = 5;

    /*Skip pixels to correct processing of boundary pixels*/
    h = height - kh;
    w = width  - kw;

    /*variables for performance*/
    double start, stop, perf;
    int nloops = 100;

    /* We cannot read pixels outside of allocated image*/
    /* so shift 2 pixels rigth and down*/
    /*It is image  */
    /*"p" is pixel we start with*/
    /* ~~~~~~~~~~~ */
    /* ~~~~~~~~~~~ */
    /* ~~p~~~~~~~~ */
    /* ~~~~~~~~~~~ */
    /* ~~~~~~~~~~~ */
    p = dst1 + st*(kh / 2) + 3 * (kw / 2);
    /*1. Initial implementation of filter Blur*/
    blur_c3(src, p, st, kh, kw, h, w);
    /*Measurement loop*/
    start = (double)__rdtsc();
    for (n = 0; n < nloops; n++) {
        blur_c3(src, p, st, kh, kw, h, w);
    }
    stop = (double)__rdtsc();
    perf = (stop - start) / nloops;
    printf("time1 = %12.3f cycles, initial\n", perf);


    /*2. First SIMD implementation*/
    p = dst2 + st*(kh / 2) + 3 * (kw / 2);
    blur_c3_simd(src, p, st, kh, kw, h, w);
    start = (double)__rdtsc();
    for (n = 0; n < nloops; n++) {
        blur_c3_simd(src, p, st, kh, kw, h, w);
    }
    stop = (double)__rdtsc();
    perf = (stop - start) / nloops;
    test(dst1, dst2, st, h,w);
    printf("time2 = %12.3f cycles, initial+simd\n", perf);

    /*3. Use separability*/
    p = dst3 + 3 * width*(kh / 2) + 3 * (kw / 2);
    float* buf[5];
    for (n = 0; n < 5; n++) {
        buf[n] = malloc(st * sizeof(float));
    }
    start = (double)__rdtsc();
    blur_c3_sep(src, p, st, kh, kw, h, w, buf);
    for (n = 0; n < nloops; n++) {
        blur_c3_sep(src, p, st, kh, kw, h, w, buf);
    }
    stop = (double)__rdtsc();
    perf = (stop - start) / nloops;
    test(dst1, dst3, st, h, w);
    printf("time3 = %12.3f cycles, separable\n", perf);

    /*4. Use separability and simd*/
    p = dst4 + st*(kh / 2) + 3 * (kw / 2);
    start = (double)__rdtsc();
    blur_c3_sep_simd(src, p, st, kh, kw, h, w, buf);
    for (n = 0; n < nloops; n++) {
        blur_c3_sep_simd(src, p, st, kh, kw, h, w, buf);
    }
    stop = (double)__rdtsc();
    perf = (stop - start) / nloops;
    test(dst1, dst4, st, h, w);

    printf("time4 = %12.3f cycles, separable+simd\n", perf);

    /*5. Use IPP*/
    uchar* s;
    s = src  + st * (kh / 2) + 3 * (kw / 2);
    p = dst5 + st * (kh / 2) + 3 * (kw / 2);
    start = (double)__rdtsc();
    blur_c3_ipp(s, p, st, kh, kw, h, w);
    for (n = 0; n < nloops; n++) {
        blur_c3_ipp(s, p, st, kh, kw, h, w);
    }
    stop = (double)__rdtsc();
    perf = (stop - start) / nloops;
    test(dst1, dst5, st, h, w);

    printf("time5 = %12.3f cycles, ipp\n", perf);

    storeBMP("dst1.bmp", dst1);
    storeBMP("dst2.bmp", dst2);
    storeBMP("dst3.bmp", dst3);
    storeBMP("dst4.bmp", dst4);
    storeBMP("dst5.bmp", dst5);


    return 0;
}


