#include <malloc.h>
typedef unsigned char uchar;
/*3. Using of IPP*/
#include "ipp.h"
void blur_c3_ipp(uchar* src, uchar* dst, int lineStep, int kh, int kw, int h, int w)
{
    IppStatus status;
    IppiSize roi = { w, h };
    IppiSize mask = { kw, kh };
    int bufferSize;
    const Ipp8u border[3] = { 0, 0, 0 };
    Ipp8u* pBuffer;
    
    ippiFilterBoxBorderGetBufferSize(roi, mask, ipp8u, 3, &bufferSize);
    pBuffer = malloc(bufferSize);
    ippiFilterBoxBorder_8u_C3R(src, lineStep, dst, lineStep, roi, mask, ippBorderInMem, border, pBuffer);
    free(pBuffer);
}
